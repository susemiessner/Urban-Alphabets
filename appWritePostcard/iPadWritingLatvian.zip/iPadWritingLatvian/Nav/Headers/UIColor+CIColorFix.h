//
//  UIColor+CIColorFix.h
//  C4iOS
//
//  Created by moi on 13-02-21.
//  Copyright (c) 2013 POSTFL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (CIColorFix)

@end
