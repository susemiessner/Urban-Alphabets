//
//  main.m
//  Nav
//
//  Created by moi on 12/5/2013.
//  Copyright (c) 2013 moi. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([C4AppDelegate class]));
    }
}
