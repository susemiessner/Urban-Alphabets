package org.susemiessner.urbanalphabets;

import java.util.ArrayList;

import android.R.integer;

public class CurrentAlphabetsInformation {
	
	
	private ArrayList<Integer> currrentAlphabets;
	
	public CurrentAlphabetsInformation(ArrayList<Integer> currrentAlphabets){

		this.currrentAlphabets=currrentAlphabets;
	}

	public ArrayList<Integer> getCurrrentAlphabets() {
		return currrentAlphabets;
	}

	public void setCurrrentAlphabets(ArrayList<Integer> currrentAlphabets) {
		this.currrentAlphabets = currrentAlphabets;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	

}
