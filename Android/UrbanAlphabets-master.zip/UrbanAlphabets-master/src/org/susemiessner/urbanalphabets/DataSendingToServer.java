package org.susemiessner.urbanalphabets;

public class DataSendingToServer {

}
